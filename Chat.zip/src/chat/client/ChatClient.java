package chat.client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {
	private static final String SERVER_HOST = "localhost";
	private static final int SERVER_PORT = 5000;

	private static String clientSendDir = System.getProperty("user.home") + File.separator + "Desktop" + File.separator
			+ "ClientSend";
	private static String clientReceiveDir = System.getProperty("user.home") + File.separator + "Desktop"
			+ File.separator + "ClientReceive";
	private static ImageHandler imageHandler = new ImageHandler();

	public static void main(String[] args) {
		File sendDir = new File(clientSendDir);
		if (!sendDir.exists())
			sendDir.mkdirs();
		File receiveDir = new File(clientReceiveDir);
		if (!receiveDir.exists())
			receiveDir.mkdirs();

		try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
				DataInputStream dis = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
				DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()))) {

			Scanner sc = new Scanner(System.in);

			// 초기 닉네임 설정
			while (true) {
				// 서버로부터 닉네임 입력 요청 메시지 받기
				byte msgType = dis.readByte();
				if (msgType != 'T') {
					System.out.println("[System]: 잘못된 메시지 타입을 받았습니다.");
					continue;
				}
				int msgLength = dis.readInt();
				byte[] msgBytes = new byte[msgLength];
				dis.readFully(msgBytes);
				String serverPrompt = new String(msgBytes, "UTF-8");
				System.out.println(serverPrompt);

				// 사용자로부터 닉네임 입력 받기
				String nickname = sc.nextLine();
				sendTextMessage(nickname, dos);

				// 서버로부터 닉네임 설정 결과 받기
				msgType = dis.readByte();
				if (msgType != 'T') {
					System.out.println("[System]: 잘못된 메시지 타입을 받았습니다.");
					continue;
				}
				msgLength = dis.readInt();
				msgBytes = new byte[msgLength];
				dis.readFully(msgBytes);
				String serverResponse = new String(msgBytes, "UTF-8");
				System.out.println(serverResponse);

				if (!serverResponse.startsWith("[System]: 이미 존재하는 닉네임입니다.")) {
					break;
				}
			}

			// 메시지 수신 스레드 시작
			Thread readerThread = new Thread(() -> {
				try {
					while (true) {
						byte msgType = dis.readByte();
						if (msgType == 'T') { // 텍스트 메시지
							int msgLength = dis.readInt();
							byte[] msgBytes = new byte[msgLength];
							dis.readFully(msgBytes);
							String msg = new String(msgBytes, "UTF-8");
							System.out.println(msg);
						} else if (msgType == 'I') { // 이미지 데이터
							handleImageReceive(socket, dis);
						} else {
							// 알 수 없는 메시지 타입
							System.out.println("알 수 없는 메시지 타입: " + msgType);
						}
					}
				} catch (IOException e) {
					// 연결 종료 시 처리
				}
			});
			readerThread.start();

			// 메시지 전송
			while (true) {
				String msg = sc.nextLine();
				if (msg.equalsIgnoreCase("/quit")) {
					break;
				} else if (msg.startsWith("/img ")) {
					handleImageSend(socket, msg.substring(5).trim(), dos);
				} else {
					sendTextMessage(msg, dos);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("클라이언트 종료.");
	}

	private static void sendTextMessage(String msg, DataOutputStream dos) throws IOException {
		// 텍스트 메시지 전송: 'T' + 메시지 길이 + 메시지 내용
		dos.writeByte('T');
		byte[] msgBytes = msg.getBytes("UTF-8");
		dos.writeInt(msgBytes.length);
		dos.write(msgBytes);
		dos.flush();
	}

	private static void handleImageSend(Socket socket, String filename, DataOutputStream dos) {
		File file = new File(clientSendDir, filename);
		if (!file.exists()) {
			System.out.println("[System]: 해당 파일이 없습니다.");
			return;
		}

		// 이미지 전송을 별도의 스레드에서 처리
		new Thread(() -> {
			try {
				// 이미지 전송 요청 메시지 전송: 'T' + 메시지 길이 + 메시지 내용
				String imgCommand = "/img " + filename;
				byte[] imgCmdBytes = imgCommand.getBytes("UTF-8");
				dos.writeByte('T');
				dos.writeInt(imgCmdBytes.length);
				dos.write(imgCmdBytes);
				dos.flush();

				// 이미지 데이터 전송: 'I' + 파일명 길이 + 파일명 + 이미지 크기
				byte[] filenameBytes = filename.getBytes("UTF-8");
				dos.writeByte('I');
				dos.writeInt(filenameBytes.length);
				dos.write(filenameBytes);
				dos.writeLong(file.length());
				dos.flush();

				// 이미지 파일 데이터 전송
				imageHandler.sendImage(socket, file, dos);

				System.out.println("[System]: 이미지 전송 완료.");
			} catch (IOException e) {
				System.out.println("[System]: 이미지 전송 중 오류 발생.");
				e.printStackTrace();
			}
		}).start();
	}

	private static void handleImageReceive(Socket socket, DataInputStream dis) {
		try {
			// 이미지 데이터: 파일명 길이 + 파일명 + 이미지 크기 + 이미지 데이터
			int filenameLength = dis.readInt();
			byte[] filenameBytes = new byte[filenameLength];
			dis.readFully(filenameBytes);
			String filename = new String(filenameBytes, "UTF-8");

			long fileLength = dis.readLong();

			// 이미지 수신 및 저장
			imageHandler.receiveImage(socket, filename, fileLength, dis);
			System.out.println("[System]: 이미지 수신 완료: " + new File(clientReceiveDir, filename).getAbsolutePath());

		} catch (IOException e) {
			System.out.println("[System]: 이미지 수신 중 오류가 발생했습니다.");
			e.printStackTrace();
		}
	}

}
