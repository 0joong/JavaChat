package chat.client;

import java.io.*;
import java.net.Socket;

public class ImageHandler {
    private static final String CLIENT_RECEIVE_DIR = System.getProperty("user.home") + File.separator + "Desktop" + File.separator + "ClientReceive";

    public ImageHandler() {
        File dir = new File(CLIENT_RECEIVE_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    // 클라이언트가 서버로 이미지를 전송하는 메서드
    public void sendImage(Socket socket, File file, DataOutputStream dos) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }
            dos.flush();
        }
    }

    // 클라이언트가 서버로부터 이미지를 수신하여 저장하는 메서드
    public void receiveImage(Socket socket, String filename, long fileLength, DataInputStream dis) throws IOException {
        File outFile = new File(CLIENT_RECEIVE_DIR, filename);
        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            byte[] buffer = new byte[4096];
            long remaining = fileLength;
            while (remaining > 0) {
                int read = dis.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                if (read == -1) break;
                fos.write(buffer, 0, read);
                remaining -= read;
            }
        }
    }
}
