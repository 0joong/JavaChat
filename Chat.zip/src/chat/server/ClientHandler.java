package chat.server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ClientHandler extends Thread {
    private Socket socket;
    private DataInputStream dis;
    private DataOutputStream dos;
    private String nickname;
    private boolean isActive = true;
    private ChatLogger logger;

    private ImageHandler imageHandler;

    public ClientHandler(Socket socket, ChatLogger logger, ImageHandler imageHandler) {
        this.socket = socket;
        this.logger = logger;
        this.imageHandler = imageHandler;
        try {
            dis = new DataInputStream(new BufferedInputStream(this.socket.getInputStream()));
            dos = new DataOutputStream(new BufferedOutputStream(this.socket.getOutputStream()));
        } catch (IOException e) {
            logger.log("클라이언트 핸들러 초기화 오류: " + e.getMessage());
            e.printStackTrace();
            isActive = false;
        }
    }


    public String getNickname() {
        return nickname;
    }

    public void sendMessage(String msg) {
        try {
            // 텍스트 메시지 전송: 'T' + 메시지 길이 + 메시지 내용
            dos.writeByte('T');
            byte[] msgBytes = msg.getBytes("UTF-8");
            dos.writeInt(msgBytes.length);
            dos.write(msgBytes);
            dos.flush();
        } catch (IOException e) {
            logger.log("메시지 전송 오류 (" + nickname + "): " + e.getMessage());
            e.printStackTrace();
            isActive = false;
        }
    }

    @Override
    public void run() {
        try {
            // 초기 닉네임 설정
            setInitialNickname();

            String line;
            while (isActive) {
                // 메시지 타입 읽기
                byte msgType;
                try {
                    msgType = dis.readByte();
                } catch (IOException e) {
                    logger.log(nickname + " 클라이언트 연결 종료.");
                    break;
                }

                if (msgType == 'T') { // 텍스트 메시지
                    int msgLength = dis.readInt();
                    byte[] msgBytes = new byte[msgLength];
                    dis.readFully(msgBytes);
                    String msg = new String(msgBytes, "UTF-8");

                    if (msg.startsWith("/rename ")) {
                        handleRename(msg.substring(8).trim());
                    } else if (msg.startsWith("/to ")) {
                        handlePrivateMessage(msg.substring(4).trim());
                    } else if (msg.startsWith("/img ")) {
                        handleImageSend(msg.substring(5).trim());
                    } else if (msg.equals("/who")) {
                        sendMessage(ChatServer.getUserList());
                        logger.log(nickname + " 요청: /who");
                    } else if (msg.startsWith("/yes ") || msg.startsWith("/no ")) {
                        handleImageResponse(msg.trim());
                    } else {
                        handleBroadcastMessage(msg);
                    }
                } else if (msgType == 'I') { // 이미지 데이터 전송 (클라이언트로부터 서버로)
                    // 현재는 처리하지 않습니다.
                } else {
                    logger.log("알 수 없는 메시지 타입 (" + nickname + "): " + msgType);
                }
            }
        } catch (IOException e) {
            logger.log("클라이언트 핸들러 오류 (" + nickname + "): " + e.getMessage());
            e.printStackTrace();
        } finally {
            cleanup();
        }
    }

    private void setInitialNickname() throws IOException {
        while (true) {
            // 닉네임 요청 메시지 전송
            sendMessage("[System]: 닉네임을 입력하세요:");

            // 텍스트 메시지 타입 읽기
            byte msgType = dis.readByte();
            if (msgType != 'T') {
                sendMessage("[System]: 올바르지 않은 닉네임 형식입니다.");
                continue;
            }
            int msgLength = dis.readInt();
            byte[] msgBytes = new byte[msgLength];
            dis.readFully(msgBytes);
            String requestedName = new String(msgBytes, "UTF-8").trim();

            if (requestedName.isEmpty()) {
                sendMessage("[System]: 닉네임은 비어 있을 수 없습니다.");
                continue;
            }

            synchronized (ChatServer.getNameToClient()) {
                if (ChatServer.getNameToClient().containsKey(requestedName)) {
                    sendMessage("[System]: 이미 존재하는 닉네임입니다. 다른 닉네임을 선택하세요.");
                } else {
                    nickname = requestedName;
                    ChatServer.getNameToClient().put(nickname, this);
                    ChatServer.getClientHandlers().add(this);
                    ChatServer.broadcastMessage("[System]: " + nickname + " 님이 접속하였습니다.");
                    logger.log(nickname + " 님이 접속하였습니다.");
                    break;
                }
            }
        }
    }

    private void handleRename(String newName) {
        if (newName.isEmpty()) {
            sendMessage("[System]: 올바른 닉네임을 입력하세요.");
            return;
        }
        synchronized (ChatServer.getNameToClient()) {
            if (ChatServer.getNameToClient().containsKey(newName)) {
                sendMessage("[System]: 이미 존재하는 닉네임입니다.");
            } else {
                ChatServer.getNameToClient().remove(nickname);
                String oldName = nickname;
                nickname = newName;
                ChatServer.getNameToClient().put(nickname, this);
                sendMessage("[System]: 닉네임이 " + nickname + " 으로 변경되었습니다.");
                ChatServer.broadcastMessage("[System]: " + oldName + " 님이 닉네임을 " + nickname + " 으로 변경하였습니다.");
                logger.log(oldName + " 님이 닉네임을 " + nickname + " 으로 변경하였습니다.");
            }
        }
    }

    private void handlePrivateMessage(String msgContent) {
        String[] split = msgContent.split(" ", 2);
        if (split.length < 2) {
            sendMessage("[System]: 형식: /to 대상닉네임 메시지");
            return;
        }
        String target = split[0];
        String msg = split[1];
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        String formattedMsg = "[" + nickname + "](" + time + ") : " + msg;
        ChatServer.sendToUser(target, formattedMsg, this);
    }

    private void handleImageSend(String filename) {
        try {
            // 'I' 바이트 읽기
            byte imageType = dis.readByte();
            if (imageType != 'I') {
                sendMessage("[System]: 예상치 못한 데이터 형식입니다.");
                logger.log(nickname + " 오류: 예상치 못한 데이터 형식 ('I' 아님).");
                return;
            }

            // 파일 이름 길이 읽기
            int filenameLength = dis.readInt();
            byte[] filenameBytes = new byte[filenameLength];
            dis.readFully(filenameBytes);
            String recvFilename = new String(filenameBytes, "UTF-8");

            // 파일 길이 읽기
            long fileLength = dis.readLong();
            logger.log(nickname + "가 이미지를 전송합니다: " + recvFilename + " (" + fileLength + " bytes)");
            System.out.println("[DEBUG] Receiving image: " + recvFilename + " (" + fileLength + " bytes)");

            // 이미지 데이터 수신
            imageHandler.receiveImage(socket, recvFilename, fileLength, dis);

            // 이미지 수신 알림 브로드캐스트
            ChatServer.broadcastImageAvailable(nickname, recvFilename);
            sendMessage("[System]: 이미지 전송이 서버에 완료되었습니다.");
            logger.log("이미지 전송 완료: " + recvFilename + " (From: " + nickname + ")");
            System.out.println("[DEBUG] Image " + recvFilename + " received successfully.");
        } catch (IOException e) {
            sendMessage("[System]: 이미지 전송 중 오류가 발생했습니다.");
            logger.log("이미지 전송 오류 (" + nickname + "): " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleImageResponse(String response) {
        String[] parts = response.split(" ", 2);
        if (parts.length < 2) return;
        String command = parts[0];
        String filename = parts[1];

        if (command.equals("/yes")) {
            try {
                imageHandler.sendImage(socket, filename, dos);
                sendMessage("[System]: 이미지 전송 완료.");
                logger.log("이미지 전송 완료: " + filename + " (To: " + nickname + ")");
            } catch (IOException e) {
                sendMessage("[System]: 이미지 전송 중 오류가 발생했습니다.");
                logger.log("이미지 전송 오류 (" + nickname + "): " + e.getMessage());
                e.printStackTrace();
            }
        } else if (command.equals("/no")) {
            sendMessage("[System]: 이미지 수신을 거절하셨습니다.");
            logger.log(nickname + "가 이미지 수신을 거절하였습니다: " + filename);
        }
    }

    private void handleBroadcastMessage(String msg) {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        String formattedMsg = "[" + nickname + "](" + time + ") : " + msg;
        ChatServer.broadcastMessage(formattedMsg);
        //logger.log("Broadcast: " + formattedMsg);
    }

    private void cleanup() {
        try {
            socket.close();
        } catch (IOException ignored) {}
        ChatServer.getClientHandlers().remove(this);
        if (nickname != null) {
            ChatServer.getNameToClient().remove(nickname);
            ChatServer.broadcastMessage("[System]: " + nickname + " 님이 퇴장하였습니다.");
            logger.log(nickname + " 님이 퇴장하였습니다.");
        }
    }

    // 클라이언트 연결 종료 메서드 (서버 종료 시 호출)
    public void closeConnection() {
        isActive = false;
        try {
            socket.close();
        } catch (IOException ignored) {}
    }
}
