package chat.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;

public class ChatServer {
    private static final int PORT = 5000;
    private static Set<ClientHandler> clientHandlers = Collections.synchronizedSet(new HashSet<>());
    private static Map<String, ClientHandler> nameToClient = Collections.synchronizedMap(new HashMap<>());
    private static ChatLogger logger = ChatLogger.getInstance();
    private static ImageHandler imageHandler = new ImageHandler();

    public static void main(String[] args) {
        logger.log("채팅 서버 시작...");
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            shutdown();
        }));
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler ch = new ClientHandler(socket, logger, imageHandler);
                ch.start();
            }
        } catch (IOException e) {
            logger.log("서버 소켓 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            shutdown();
        }
    }

    // 접근자 메서드
    public static Set<ClientHandler> getClientHandlers() {
        return clientHandlers;
    }

    public static Map<String, ClientHandler> getNameToClient() {
        return nameToClient;
    }

    // 전체 메시지 브로드캐스트
    public static void broadcastMessage(String msg) {
        logger.log("Broadcast: " + msg);
        synchronized (clientHandlers) {
            for (ClientHandler ch : clientHandlers) {
                ch.sendMessage(msg);
            }
        }
    }

    // 특정 사용자에게만 메시지 보내기
    public static void sendToUser(String targetName, String msg, ClientHandler from) {
        ClientHandler target = nameToClient.get(targetName);
        if (target != null && target.isAlive()) {
            logger.log("Private from " + from.getNickname() + " to " + targetName + ": " + msg);
            target.sendMessage(msg);
        } else {
            from.sendMessage("[System]: 대상 사용자가 오프라인입니다.");
            logger.log("Failed private message from " + from.getNickname() + " to " + targetName + ": User offline.");
        }
    }

    // 온라인 사용자 목록 반환
    public static String getUserList() {
        StringBuilder sb = new StringBuilder();
        sb.append("현재 온라인 사용자:\n");
        synchronized (nameToClient) {
            for (String name : nameToClient.keySet()) {
                sb.append(" - ").append(name).append("\n");
            }
        }
        return sb.toString();
    }

    // 이미지 브로드캐스트 알림
    public static void broadcastImageAvailable(String fromName, String filename) {
        String msg = "[System]: " + fromName + "님이 이미지를 업로드했습니다. 받으시겠습니까? (/yes " + filename + " /no " + filename + ")";
        logger.log("Image available from " + fromName + ": " + filename);
        synchronized (clientHandlers) {
            for (ClientHandler ch : clientHandlers) {
                ch.sendMessage(msg);
            }
        }
    }

    // 서버 종료 시 로그 파일 닫기
    public static void shutdown() {
        logger.log("채팅 서버 종료.");
        logger.close();
        // 모든 클라이언트 핸들러 종료
        synchronized (clientHandlers) {
            for (ClientHandler ch : clientHandlers) {
                ch.closeConnection();
            }
        }
    }
}
