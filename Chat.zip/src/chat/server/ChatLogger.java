package chat.server;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class ChatLogger {
    private static ChatLogger instance = null;
    private BufferedWriter writer;

    private ChatLogger() {
        try {
            String desktopPath = System.getProperty("user.home") + File.separator + "Desktop";
            File logFile = new File(desktopPath, "log.txt");
            // 파일이 없으면 생성, 있으면 이어쓰기
            writer = new BufferedWriter(new FileWriter(logFile, true));
        } catch (IOException e) {
            System.err.println("[ChatLogger]: 로그 파일 생성 또는 열기 중 오류 발생.");
            e.printStackTrace();
        }
    }

    // 싱글톤 인스턴스 접근 메서드
    public static synchronized ChatLogger getInstance() {
        if (instance == null) {
            instance = new ChatLogger();
        }
        return instance;
    }

    // 로그 기록 메서드
    public synchronized void log(String message) {
        try {
        	System.out.println(message);
            String timestamp = LocalDateTime.now().toString();
            writer.write("[" + timestamp + "] " + message);
            writer.newLine();
            writer.flush();
        } catch (IOException e) {
            System.err.println("[ChatLogger]: 로그 기록 중 오류 발생.");
            e.printStackTrace();
        }
    }

    // 자원 해제 메서드 (서버 종료 시 호출)
    public synchronized void close() {
        try {
            if (writer != null) {
                writer.close();
            }
        } catch (IOException e) {
            System.err.println("[ChatLogger]: 로그 파일 닫기 중 오류 발생.");
            e.printStackTrace();
        }
    }
}
