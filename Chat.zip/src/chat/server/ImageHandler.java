package chat.server;

import java.io.*;
import java.net.Socket;

public class ImageHandler {
	private static final String SERVER_IMG_DIR = System.getProperty("user.home") + File.separator + "Desktop"
			+ File.separator + "ServerImg";

	public ImageHandler() {
		File dir = new File(SERVER_IMG_DIR);
		if (!dir.exists()) {
			dir.mkdirs();
		}
	}

	// 서버가 클라이언트로부터 이미지를 수신하고 저장하는 메서드
	public void receiveImage(Socket socket, String filename, long fileLength, DataInputStream dis) throws IOException {
		File outFile = new File(SERVER_IMG_DIR, filename);
		try (FileOutputStream fos = new FileOutputStream(outFile)) {
			byte[] buffer = new byte[4096];
			long remaining = fileLength;
			while (remaining > 0) {
				int read = dis.read(buffer, 0, (int) Math.min(buffer.length, remaining));
				if (read == -1)
					break;
				fos.write(buffer, 0, read);
				remaining -= read;
			}
		}
	}

	// 서버가 클라이언트에게 이미지를 전송하는 메서드
	public void sendImage(Socket socket, String filename, DataOutputStream dos) throws IOException {
		File imgFile = new File(SERVER_IMG_DIR, filename);
		if (!imgFile.exists()) {
			// 파일이 존재하지 않을 경우, 클라이언트에 오류 메시지 전송
			sendErrorMessage(dos, "해당 이미지가 서버에 존재하지 않습니다.");
			return;
		}

		// 이미지 데이터 전송: 'I' + 파일명 길이 + 파일명 + 이미지 크기 + 이미지 데이터
		dos.writeByte('I');
		byte[] filenameBytes = filename.getBytes("UTF-8");
		dos.writeInt(filenameBytes.length);
		dos.write(filenameBytes);
		dos.writeLong(imgFile.length());

		try (FileInputStream fis = new FileInputStream(imgFile)) {
			byte[] buffer = new byte[4096];
			int bytesRead;
			while ((bytesRead = fis.read(buffer)) != -1) {
				dos.write(buffer, 0, bytesRead);
			}
			dos.flush();
		}
	}

	// 오류 메시지 전송 메서드 추가
	private void sendErrorMessage(DataOutputStream dos, String errorMsg) throws IOException {
		// 텍스트 메시지 전송: 'T' + 메시지 길이 + 메시지 내용
		dos.writeByte('T');
		byte[] msgBytes = errorMsg.getBytes("UTF-8");
		dos.writeInt(msgBytes.length);
		dos.write(msgBytes);
		dos.flush();
	}

}
